# GAVEL Central Server

The shared, multi-tenant server that fronts the user-facing parts of the
GAVEL platform. Each user runs the **local backend** (`../backend/`) on
their own GPU host for model training. That local backend talks to this
central server over HTTP for anything that needs to be shared across
users or that requires the HF write token.

## What this server owns

- **Users + auth** — single global user table, JWT-signed tokens
- **Ratings** — per-user ratings of public rules/CEs, with denormalized
  aggregates (asset_ratings_summary, user_ratings_summary)
- **Bookmarks** — per-user bookmarks of public rules/CEs, keyed by HF
  `public_id` so they're portable across machines
- **HF write proxy** — `POST /hf/commit` accepts a batch of file ops
  from a local backend and commits them to the HuggingFace registry
  using the server's `HF_TOKEN`. Local backends never see the token.

## What it does NOT own

- Model files, classifiers, training data — these stay on each user's
  local backend (they're huge and per-user)
- The HF registry itself — that's HuggingFace, unchanged
- The user's local cache of rules/CEs — local backend syncs that
  directly from HF (read-only access)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  USER'S LOCAL BACKEND (backend/)                                │
│  - own GPU host                                                 │
│  - models, classifiers, training data                           │
│  - local cache of rules/CEs                                     │
│  - calls central server for: auth, ratings, bookmarks, publish  │
└─────────────────────────────────────────────────────────────────┘
                              │ HTTPS
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  CENTRAL SERVER (this directory)                                │
│  - one shared instance (Render → eventually university server)  │
│  - users, ratings, bookmarks tables                             │
│  - holds the HF write token                                     │
└─────────────────────────────────────────────────────────────────┘
                              │ HF SDK (with HF_TOKEN)
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  HUGGINGFACE DATASET REPO (unchanged)                           │
│  - public_ces/*.json, public_rules/*.json, manifest.json, ...   │
└─────────────────────────────────────────────────────────────────┘
```

## Local development

```bash
cd central-server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in DATABASE_URL, JWT_SECRET_KEY, HF_TOKEN
uvicorn app.main:app --reload --port 8001
```

Then in `../backend/.env`:
```
CENTRAL_SERVER_URL=http://localhost:8001
JWT_SECRET_KEY=<same value as central-server/.env>
```

## Deploying to Render

1. Push this repo to GitHub
2. In Render dashboard → **New** → **Blueprint** → connect this repo
3. Render reads `render.yaml` and provisions a web service + PostgreSQL
4. Set these secrets in the web service's **Environment** tab:
   - `JWT_SECRET_KEY` — `python -c "import secrets; print(secrets.token_urlsafe(48))"`
   - `HF_TOKEN` — write-scope token from HuggingFace
   - `ALLOWED_ORIGINS` — your frontend URL(s), comma-separated
5. Wait for the build (~3 min), then test: `curl https://<your-app>.onrender.com/health`
6. Update `backend/.env`:
   ```
   CENTRAL_SERVER_URL=https://<your-app>.onrender.com
   JWT_SECRET_KEY=<same value as set on Render>
   ```

## Swapping to the university server later

When the university provides a real server, you change ONE env var on each
local backend:
```
CENTRAL_SERVER_URL=https://gavel.cs.university.edu
```
…plus copy `JWT_SECRET_KEY` to the new server. Local backends don't need
any code changes — the HTTP client (`backend/services/central_server.py`)
talks to whatever URL is configured.

## API surface

| Method | Path | Auth | Purpose |
|--------|------|------|---------|
| POST | `/auth/register` | none | Create user account |
| POST | `/auth/login` | none | Authenticate + return JWT |
| GET | `/auth/me` | bearer | Current user's profile |
| PATCH | `/auth/me` | bearer | Update display_name / bio |
| PUT | `/auth/tutorial-seen` | bearer | Mark onboarding complete |
| GET | `/auth/users/{user_id}` | bearer | Lookup user by id |
| GET | `/auth/users/by-username?usernames=a,b,c` | none | Bulk username → user lookup (used by HF sync) |
| POST | `/ratings` | bearer | Upsert (1-5) rating on rule/CE |
| DELETE | `/ratings/{type}/{public_id}` | bearer | Withdraw rating |
| GET | `/ratings/{type}/{public_id}` | bearer | Aggregate + your score |
| POST | `/bookmarks` | bearer | Add bookmark by public_id |
| DELETE | `/bookmarks/{type}/{public_id}` | bearer | Remove bookmark |
| GET | `/bookmarks/{type}` | bearer | List your bookmarks (public_ids) |
| POST | `/hf/commit` | bearer | Commit a batch of files to HF |
| GET | `/hf/head-sha` | bearer | Current HEAD SHA (for race detection) |
| GET | `/health` | none | Liveness probe |
