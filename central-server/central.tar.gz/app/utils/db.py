"""Single PostgreSQL connection pool for the central server.

Reads DATABASE_URL from the environment (Render injects this automatically
when a Postgres service is linked). Falls back to discrete DB_* vars for
local dev so you can point at a docker-compose postgres.
"""
import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from psycopg2 import extras, pool

env_path = Path(__file__).parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

DATABASE_URL: Optional[str] = os.getenv("DATABASE_URL")

_pool: Optional[pool.SimpleConnectionPool] = None


def _get_pool() -> pool.SimpleConnectionPool:
    global _pool
    if _pool is None:
        if not DATABASE_URL:
            raise RuntimeError(
                "DATABASE_URL is not set. Configure it in central-server/.env "
                "or in the Render service environment."
            )
        _pool = pool.SimpleConnectionPool(1, 10, dsn=DATABASE_URL)
    return _pool


def get_conn():
    return _get_pool().getconn()


def release_conn(conn):
    if conn:
        _get_pool().putconn(conn)


def execute(query: str, params=None):
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute(query, params) if params else cur.execute(query)
        results = cur.fetchall() if cur.description else None
        conn.commit()
        cur.close()
        return results
    except Exception:
        conn.rollback()
        raise
    finally:
        release_conn(conn)


def execute_dict(query: str, params=None):
    conn = get_conn()
    try:
        cur = conn.cursor(cursor_factory=extras.RealDictCursor)
        cur.execute(query, params) if params else cur.execute(query)
        results = cur.fetchall() if cur.description else None
        conn.commit()
        cur.close()
        return results
    except Exception:
        conn.rollback()
        raise
    finally:
        release_conn(conn)


def close_pool():
    global _pool
    if _pool is not None:
        _pool.closeall()
        _pool = None
