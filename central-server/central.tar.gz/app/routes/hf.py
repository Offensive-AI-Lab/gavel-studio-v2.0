"""HuggingFace write proxy.

The HF token lives only here. Local backends send a list of file
operations + a commit message; this server commits them to the public
library repo on HuggingFace.

Read operations (manifest fetch, registry sync) do NOT need this proxy
— they use the public anonymous endpoints. Only writes route through
here, which is the security boundary we care about.
"""
import base64
import os
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..utils.auth import get_current_user

router = APIRouter(prefix="/hf", tags=["huggingface"])

HF_TOKEN = os.getenv("HF_TOKEN")
REPO_ID = os.getenv("HF_REPO_ID", "GavelPublicData/public-library")
REPO_TYPE = os.getenv("HF_REPO_TYPE", "dataset")


class FileOp(BaseModel):
    """One file to upload. `content_b64` is base64-encoded bytes."""
    path: str = Field(..., min_length=1, max_length=512)
    content_b64: str


class CommitRequest(BaseModel):
    operations: List[FileOp] = Field(..., min_length=1, max_length=100)
    commit_message: str = Field(..., min_length=1, max_length=512)
    parent_commit: Optional[str] = None  # SHA for race detection


class CommitResponse(BaseModel):
    status: str  # "success" or "race" or "error"
    commit_sha: Optional[str] = None
    error: Optional[str] = None


def _is_race_error(exc: Exception) -> bool:
    msg = str(exc)
    return (
        "412" in msg
        or "precondition" in msg.lower()
        or "stale" in msg.lower()
        or "fetch first" in msg.lower()
        or "out-of-date" in msg.lower()
    )


@router.post("/commit", response_model=CommitResponse)
def hf_commit(req: CommitRequest, _: int = Depends(get_current_user)):
    """Commit a batch of files to the HF registry atomically.

    Requires a valid central-server JWT (any logged-in user). The user
    identity is NOT propagated to HF — the commit is attributed to the
    bot account that owns HF_TOKEN. Attribution flows through the
    payload's `created_by_username` field instead.
    """
    if not HF_TOKEN:
        raise HTTPException(status_code=503, detail="Central server has no HF_TOKEN configured")

    from huggingface_hub import CommitOperationAdd, HfApi

    api = HfApi(token=HF_TOKEN)
    ops = []
    for f in req.operations:
        try:
            content = base64.b64decode(f.content_b64)
        except Exception:
            raise HTTPException(status_code=400, detail=f"Invalid base64 in '{f.path}'")
        ops.append(CommitOperationAdd(path_in_repo=f.path, path_or_fileobj=content))

    try:
        info = api.create_commit(
            repo_id=REPO_ID,
            repo_type=REPO_TYPE,
            operations=ops,
            commit_message=req.commit_message,
            parent_commit=req.parent_commit,
        )
        return CommitResponse(status="success", commit_sha=getattr(info, "oid", None) or getattr(info, "commit_oid", None))
    except Exception as e:
        if _is_race_error(e):
            return CommitResponse(status="race", error=str(e))
        return CommitResponse(status="error", error=str(e))


@router.get("/head-sha")
def get_head_sha():
    """Returns the current HEAD commit SHA of the HF repo. Used by the
    local backend to set `parent_commit` for race detection, and by the
    startup library-sync thread to check whether the cached manifest is
    stale.

    Intentionally PUBLIC (no `Depends(get_current_user)`):
      * The HEAD SHA is non-sensitive — anyone with curl can hit the
        underlying HF REST API and get the same value, no token needed.
        Gating it on a JWT here just creates noise without adding any
        protection.
      * The startup library-sync thread runs before any user is logged
        in (the local backend has no JWT to forward yet). Requiring
        auth produces a 401 log line on every backend restart, which
        the calling code already catches + continues from — making the
        check pure tax with no signal.

    What IS still gated: the actual /hf/commit endpoint that writes
    to HF (publish_ce / publish_rule path). That stays authed.
    """
    if not HF_TOKEN:
        raise HTTPException(status_code=503, detail="Central server has no HF_TOKEN configured")
    from huggingface_hub import HfApi
    api = HfApi(token=HF_TOKEN)
    try:
        info = api.repo_info(repo_id=REPO_ID, repo_type=REPO_TYPE)
        return {"sha": info.sha}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"HF read failed: {e}")
