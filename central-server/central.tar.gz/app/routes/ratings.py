"""Ratings endpoints — one row per (user, asset)."""
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..utils.auth import get_current_user
from ..utils.db import execute, execute_dict

router = APIRouter(prefix="/ratings", tags=["ratings"])

AssetType = Literal["rule", "ce"]


class RateRequest(BaseModel):
    asset_type: AssetType
    asset_public_id: str = Field(..., min_length=1, max_length=255)
    score: int = Field(..., ge=1, le=5)


class RatingSummary(BaseModel):
    rating_count: int = 0
    rating_avg: Optional[float] = None
    your_score: Optional[int] = None


def _summary(asset_type: str, asset_public_id: str, user_id: Optional[int]) -> RatingSummary:
    rows = execute_dict(
        "SELECT rating_count, rating_sum FROM asset_ratings_summary "
        "WHERE asset_type = %s AND asset_public_id = %s",
        (asset_type, asset_public_id),
    )
    count, total = (rows[0]["rating_count"], rows[0]["rating_sum"]) if rows else (0, 0)
    avg = round(total / count, 2) if count else None

    your_score = None
    if user_id is not None:
        own = execute_dict(
            "SELECT score FROM ratings WHERE user_id = %s AND asset_type = %s AND asset_public_id = %s",
            (user_id, asset_type, asset_public_id),
        )
        if own:
            your_score = own[0]["score"]

    return RatingSummary(rating_count=count, rating_avg=avg, your_score=your_score)


@router.post("")
def upsert_rating(req: RateRequest, user_id: int = Depends(get_current_user)):
    execute(
        """
        INSERT INTO ratings (user_id, asset_type, asset_public_id, score)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (user_id, asset_type, asset_public_id) DO UPDATE
        SET score = EXCLUDED.score, updated_at = now()
        """,
        (user_id, req.asset_type, req.asset_public_id, req.score),
    )
    return _summary(req.asset_type, req.asset_public_id, user_id).dict()


@router.delete("/{asset_type}/{asset_public_id}")
def delete_rating(asset_type: AssetType, asset_public_id: str, user_id: int = Depends(get_current_user)):
    execute(
        "DELETE FROM ratings WHERE user_id = %s AND asset_type = %s AND asset_public_id = %s",
        (user_id, asset_type, asset_public_id),
    )
    return _summary(asset_type, asset_public_id, user_id).dict()


@router.get("/{asset_type}/{asset_public_id}")
def get_rating_summary(
    asset_type: AssetType,
    asset_public_id: str,
    user_id: int = Depends(get_current_user),
):
    return _summary(asset_type, asset_public_id, user_id).dict()
