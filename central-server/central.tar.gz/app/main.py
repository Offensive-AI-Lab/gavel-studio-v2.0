"""Central server entrypoint.

Run locally:
    cd central-server
    pip install -r requirements.txt
    cp .env.example .env  # fill in DATABASE_URL, JWT_SECRET_KEY, HF_TOKEN
    uvicorn app.main:app --reload --port 8001

In production (Render):
    Render runs `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
"""
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import auth, bookmarks, hf, ratings, users
from .utils.schema import init_schema

app = FastAPI(title="GAVEL Central Server", version="0.1.0")

allowed_origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in allowed_origins if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(ratings.router)
app.include_router(bookmarks.router)
app.include_router(hf.router)


@app.on_event("startup")
def on_startup():
    try:
        init_schema()
    except Exception as e:
        print(f"Schema init error: {e}")


@app.get("/")
def root():
    return {"service": "gavel-central-server", "status": "ok"}


@app.get("/health")
def health():
    return {"status": "ok"}
